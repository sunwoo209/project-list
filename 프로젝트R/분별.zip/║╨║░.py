print("MBTI를 선호경향별 과업처리 스타일을 파악하기 위한 질문지 입니다.")
print("질문에 응하실때 [비동의] 1   ~    5 [동의] 의 점수로 숫자를 입력해주세요")
print("\n")
E1=(int(input("1. 다양하고 활동적인 일을 선호한다.")))
E2=(int(input("2. 다른 사람들이 일한 결과와 어떻게 일하는지에 관심이 많다.")))
E3=(int(input("3. 미리 생각하지 않고 행동으로먼저 옮긴다.")))
I1=(int(input("4. 일 뒤에 있는 사실이나 관념에 관심이 있다.")))
I2=(int(input("5. 행동하기 전에 많이 생각하고 때로는 생각만 하고 그친다.")))
I3=(int(input("6. 혼자서 일하는 것을 좋아한다.")))
EI=(15+E1+E2+E3+(-I1-I2-I3+3))
if EI>=18:
     EIdex=str("E")
else:
     EIdex=str("I")


S1=(int(input("7. 문제해결을 위해 경험과 기준을사용하는 것을 좋아한다.")))
S2=(int(input("8. 이미 알고 있는 방법을 적용하기 좋아한다.")))
S3=(int(input("9. 실질적인 일을 하는 것을 좋아한다.")))
N1=(int(input("10. 새롭고 복잡한 문제해결을 좋아한다.")))
N2=(int(input("11. 사용하지 않은 기술을 배우는 것을 좋아한다.")))
N3=(int(input("12. 혁신적인 일을 좋아한다.")))
SN=(15+S1+S2+S3+(-N1-N2-N3+3))
if SN>=18:
     SNdex=str("S")
else:
     SNdex=str("N")

T1=(int(input("13. 논리적인 분석을 이용하여 결론에 도달한다.")))
T2=(int(input("14. 의지력이 강한 경향이 있으며 적당한 때에 비판을 할 수 있다.")))
T3=(int(input("15. 상황에 포함된 원칙을 관찰한다.")))
F1=(int(input("16. 가치를 이용하여 결론에 도달한다.")))
F2=(int(input("17. 다른 사람들이 좋아하고 싫어하는데 영향을 받아 결정을 내리기도 한다.")))
F3=(int(input("18. 상황 속에 깔려 있는 가치를 관찰한다.")))
TF=(15+T1+T2+T3+(-F1-F2-F3+3))
if TF>=18:
     TFdex=str("T")
else:
     TFdex=str("F")

J1=(int(input("19. 계획을 세우고 그것에 따라 일할 때 잘한다.")))
J2=(int(input("20. 일을 완결하고 끝내는 것을 좋아한다.")))
J3=(int(input("21. 구조와 계획을 찾는다.")))
P1=(int(input("22. 일을 하는데 융통성을 즐긴다.")))
P2=(int(input("23. 사용하지 않은 기술을 배우는 것을 좋아한다.")))
JP=(15+J1+J2+J3+((-P1-P2)*1.5+3))
if JP>=18:
     JPdex=str("J")
else:
     JPdex=str("P")

MBTI=EIdex+SNdex+TFdex+JPdex

print("당신은",MBTI,"의 성향을 가진것으로 판단되었고,")

if MBTI=="ESTJ":
    print("당신에게 추천되는 직업 적성은")
    print("1.보험설계사")
    print("2.약사")
    print("3.변호사")
    print("4.판사")
    print("5.프로젝트 매니저")

if MBTI=="ISTJ":
    print("1.회계감사관")
    print("2.회계사")
    print("3.최고재무책임자(CFO)")
    print("4.웹 개발자")
    print("5.공무원")

if MBTI=="ESFJ":
    print("1.영업기사")
    print("2.간호사")
    print("3.사회복지사")
    print("4.광고 기획자")
    print("5.여신 심사역")

if MBTI=="ISFJ":
    print("1.치과의사")
    print("2.초등학교 교사")
    print("3.사서")
    print("4.프랜차이즈 점수")
    print("5.고객 서비스 상담원")

if MBTI=="ESTP":
    print("1.경찰관")
    print("2.은행원")
    print("3.투자자")
    print("4.연예 기획사 에이전트")
    print("5.스포츠팀 코치")

if MBTI=="ISTP":
    print("1.토목기사")
    print("2.경제학자")
    print("3.조종사")
    print("4.데이터 분석가")
    print("5.응급처치 전문의")

if MBTI=="ESFP":
    print("1.아동상담가")
    print("2.일차진료의사")
    print("3.배우")
    print("4.인테리어 디자이너")
    print("5.환경학자")

if MBTI=="ENFJ":
    print("1.광고이사")
    print("2.홍보 전문가")
    print("3.기엄교육 전문가")
    print("4.판매부장")
    print("5.인사담당자")

if MBTI=="INFJ":
    print("1.심리 상담가")
    print("2.사회 복지사")
    print("3.다양성 전문 인사담당자")
    print("4.조직개발 컨설턴트")

if MBTI=="ENTP":
    print("1.경영자")
    print("2.부동산 개발업자")
    print("3.광고홍보 디렉터")
    print("4.마케팅 디렉터")
    print("5.정치인")

if MBTI=="INTP":
    print("1.컴퓨터 프로그래머")
    print("2.금융 애널리스트")
    print("3.건축가")
    print("4.대학교수")
    print("5.이코노미스트")

if MBTI=="ENFP":
    print("1.저널리스트")
    print("2.광고 홍보 디렉터")
    print("3.컨설턴트")
    print("4.식당 경영자")
    print("5.이벤트 플래너")

if MBTI=="INFP":
    print("1.그래픽 디자이너")
    print("2.심리학자")
    print("3.작가")
    print("4.물리치료사")
    print("5.역량 관리 책임자")

if MBTI=="ISFP":
    print("1.패션 디자이너")
    print("2.물리 치료사")
    print("3.마사지 치료사")
    print("4.조경사")
    print("5.창고관리인")

if MBTI=="ENTJ":
    print("1.기업 임원")
    print("2.변호사")
    print("3.시장조사 분석가")
    print("4.경영 컨설턴트")
    print("5.벤처 투자자")

if MBTI=="INTJ":
    print("1.투자 은행원")
    print("2.개인투자 전문가")
    print("3.소프트웨어 개발자")
    print("4.이코노미스트")
    print("5.기업 임원")
     
